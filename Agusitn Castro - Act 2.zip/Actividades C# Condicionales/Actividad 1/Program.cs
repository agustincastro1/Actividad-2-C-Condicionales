﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividades_C_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
              Realizar un programa que lea por teclado dos números, si el primero es mayor al segundo informar su suma y diferencia,
              en caso contrario informar el producto y la división del primero respecto al segundo.
             */
            int num1, num2, suma, mayor, diferencia, producto;
            double division;
            string linea;

            Console.WriteLine("Escriba el primer numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.WriteLine("Escriba el segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);



            if (num1 > num2)
            {
                suma = num1 + num2;
                diferencia = num1 - num2;
                Console.Write("El primer numero es mayor, y su suma es: ");
                Console.WriteLine(suma);
                Console.Write("Y su diferencia es: ");
                Console.WriteLine(diferencia);
            }
            else
            {
                producto = num1 * num2;
                division = num2 / num1;
                Console.Write("El Segundo numero es mayor, y su producto es: ");
                Console.WriteLine(producto);
                Console.Write("Y su division es: ");
                Console.WriteLine(division);
            }
            Console.ReadKey();
        }
    }
}
