﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Se ingresan seis notas de un alumno, si el promedio es mayor
            o igual a siete mostrar un mensaje "Promocionado"
            */
            int nota1, nota2, nota3, nota4, nota5, nota6;
            double Promedio;
            string linea;

            Console.WriteLine("ingrese el primer numero: ");
            linea = Console.ReadLine();
            nota1 = int.Parse(linea);

            Console.WriteLine("ingrese el segundo numero: ");
            linea = Console.ReadLine();
            nota2 = int.Parse(linea);

            Console.WriteLine("ingrese el tercer numero: ");
            linea = Console.ReadLine();
            nota3 = int.Parse(linea);

            Console.WriteLine("ingrese el cuerto numero: ");
            linea = Console.ReadLine();
            nota4 = int.Parse(linea);

            Console.WriteLine("ingrese el quinto numero: ");
            linea = Console.ReadLine();
            nota5 = int.Parse(linea);

            Console.WriteLine("ingrese el sexto numero: ");
            linea = Console.ReadLine();
            nota6 = int.Parse(linea);

            Promedio = (nota1 + nota2 + nota3 + nota4 + nota5 + nota6) / 6;

            if (Promedio >= 7)
            {
                Console.Write("Promocionado");
            }
            Console.ReadKey();
        }
    }
}
