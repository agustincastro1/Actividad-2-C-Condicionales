﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.Datos a tener en cuenta para la entrega:
            int num1, num2, num3;
            string linea;

            Console.WriteLine("Escriba el primer numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.WriteLine("Escriba el segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.WriteLine("Escriba el tercer numero: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.Write("El primer numero es mas grande");
                }
            }
            if (num2 > num1)
            {
                if (num2 > num3)
                {
                    Console.Write("El segundo numero es mas grande");
                }
            }
            if (num3 > num1)
            {
                if (num3 > num2)
                {
                    Console.Write("El tercer numero es mas grande");
                }
            }
            Console.ReadLine();
        }
    }
}
