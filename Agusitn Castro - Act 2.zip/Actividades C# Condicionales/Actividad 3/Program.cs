﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Se ingresa por teclado un número positivo de uno o dos dígitos (1..99)
            mostrar un mensaje indicando si el número tiene uno o dos dígitos.
            */

            int num;
            string linea;
            Console.WriteLine("Ingrese un numero positivo de uno o 2 digitos: ");
            linea = Console.ReadLine();
            num = int.Parse(linea);

            if ( num <= 9)
            {if(num > 0) 
            {
             Console.Write("El numero tiene un digito");
            }
            }
            if (num >= 10) 
            {if(num <= 99) 
            { 
              Console.Write("El numero tiene 2 digitos");
            }
            }
            Console.ReadKey();
        }
    }
}
